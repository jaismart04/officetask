
<?php $__env->startSection('content'); ?>

<div class="page-wrapper">
    <!--page-content-wrapper-->
    <div class="page-content-wrapper">
        <div class="page-content">
            <!--breadcrumb-->

            <!--end breadcrumb-->
            <div class="card">
                <div class="card-body">
                    <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>


                    <div class="row">
                        <div class="col-xl-12 mx-auto">
                            <div class="">
                                <div class="">

                                    <form action="<?php echo e(url('employee-save')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="border p-4 rounded">
                                            <div class="card-title d-flex align-items-center">
                                                <div><i class="bx bxs-user me-1 font-22 text-info"></i>
                                                </div>
                                                <h5 class="mb-0 text-info">Employee Registration</h5>
                                            </div>
                                            <hr>
                                            <?php $__currentLoopData = $company; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <input type="hidden" name="company_id" value="<?php echo e($cm->id); ?>">
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <div class="row mb-3">
                                                <label for="inputEnterYourName" class="col-sm-3 col-form-label">
                                                    Choose Company <span style="color:red;">*</span></label>
                                                <div class="col-sm-9">
                                                    <select class="form-select mb-3" name="company"
                                                        aria-label="Default select example">
                                                        <option selected=""> Choose Company</option>
                                                        <?php $__currentLoopData = $company; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($cm->company_name); ?>"><?php echo e($cm->company_name); ?>

                                                        </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="row mb-3">
                                                <label for="inputEnterYourName" class="col-sm-3 col-form-label">
                                                    First Name <span style="color:red;">*</span></label>
                                                <div class="col-sm-9">
                                                    <input type="text" class="form-control" name="first_name"
                                                        id="inputEntercompanyName" placeholder="Enter first Name"
                                                        value="<?php echo e(old('first_name')); ?>">
                                                </div>
                                            </div>

                                            <div class="row mb-3">
                                                <label for="inputEnterYourName" class="col-sm-3 col-form-label">
                                                    last Name <span style="color:red;">*</span></label>
                                                <div class="col-sm-9">
                                                    <input type="text" class="form-control" name="last_name"
                                                        id="inputEntercompanyName" placeholder="Enter last Name"
                                                        value="<?php echo e(old('last_name')); ?>">
                                                </div>
                                            </div>


                                            <div class="row mb-3">
                                                <label for="inputEmailAddress2" class="col-sm-3 col-form-label">Email
                                                    Address</label>
                                                <div class="col-sm-9">
                                                    <input type="email" class="form-control" name="email"
                                                        id="inputEmailAddress2" placeholder="Email Address"
                                                        value="<?php echo e(old('email')); ?>">
                                                </div>
                                            </div>


                                            <div class="row mb-3">
                                                <label for="inputEnterYourName" class="col-sm-3 col-form-label">
                                                    Phone</label>
                                                <div class="col-sm-9">
                                                    <input type="text" class="form-control" name="phone"
                                                        id="inputEntercompanyName" placeholder="Enter number"
                                                        value="<?php echo e(old('phone')); ?>">
                                                </div>
                                            </div>

                                            <div class="row">
                                                <label class="col-sm-3 col-form-label"></label>
                                                <div class="col-sm-9">
                                                    <button type="submit"
                                                        class="btn btn-info px-5 float-right">Save</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>
    <!--end page-content-wrapper-->
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\job\resources\views/employee/add.blade.php ENDPATH**/ ?>