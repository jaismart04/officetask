

<div class="page-wrapper">
    <!--page-content-wrapper-->
    <div class="page-content-wrapper">
        <div class="page-content">
            <div class="card radius-15 mt-2">
                <div class="card-body">
                    <div class="bg-light clearfix">
                        <button type="button" data-toggle="modal" data-target="#addweeks"
                            class="btn btn-primary m-1 px-5 float-right"><i class="bx bx-user me-1"></i> Add Weeks
                        </button>
                        <div class="modal fade bd-example-modal-lg" id="addweeks" tabindex="-1" role="dialog"
                            aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered  modal-lg" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLongTitle">Add Weeks</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="card-body">
                                            <!-- <form class="row g-3 needs-validation"> -->
                                            <form action="http://localhost/mywork/home/add_weeks" name="add_weeks"
                                                class="row g-3" id="xin-form_weeks" autocomplete="off"
                                                enctype="multipart/form-data" method="post" accept-charset="utf-8">
                                                <input type="hidden" id="user_id" name="user_id" value="1">
                                                <div class="col-md-12 mt-2">
                                                    <label for="inputEmail" class="form-label">Weeks Name</label>
                                                    <input type="text" placeholder="Weeks Name" name="week_name"
                                                        class="form-control" id="week_name">
                                                </div>
                                                <div class="col-md-6 mt-2">
                                                    <div class="mb-3">

                                                    </div>

                                                </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary"
                                            data-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary">Save</button>
                                    </div>

                                    </form>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="card-body">
                        <div class="box-datatable table-responsive">
                            <table class="datatables-demo table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>S.no</th>
                                        <th width="380">Title</th>
                                        <th>action</th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>


    <!--end page-content-wrapper-->
</div>


<!-- Modal -->
<div class="modal fadeInLeft delete-modal animated " role="dialog" aria-hidden="true">
    <!-- <div class="modal fade delete-modal" id="deleteModal" tabindex="-1" role="dialog"
        aria-labelledby="exampleModalLabel" aria-hidden="true"> -->
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>


            <div class="modal-body">
                Are you sure?
                <form action="http://localhost/mywork/home/weeks" name="delete_record_weeks" id="delete_record_weeks"
                    autocomplete="off" role="form" method="post" accept-charset="utf-8">
                    <input type="hidden" name="_method" value="DELETE" />
                    <input type="hidden" name="_token" value="000" />
                    <input type="hidden" name="token_type" value="0" id="token_type" />
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-danger">Delete</button>
            </div>
            </form>
        </div>
    </div>
</div>



<script src="<?php echo e(url('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(url('js/popper.min.js')); ?>"></script>
<script src="<?php echo e(url('js/bootstrap.min.js')); ?>"></script>
<!--plugins-->
<script src="<?php echo e(url('plugins/simplebar/js/simplebar.min.js')); ?>"></script>
<script src="<?php echo e(url('plugins/metismenu/js/metisMenu.min.js')); ?>"></script>
<script src="<?php echo e(url('plugins/perfect-scrollbar/js/perfect-scrollbar.js')); ?>"></script>
<!-- Vector map JavaScript -->
<script src="<?php echo e(url('plugins/vectormap/jquery-jvectormap-2.0.2.min.js')); ?>"></script>
<script src="<?php echo e(url('plugins/vectormap/jquery-jvectormap-world-mill-en.js')); ?>"></script>
<script src="<?php echo e(url('plugins/vectormap/jquery-jvectormap-in-mill.js')); ?>"></script>
<script src="<?php echo e(url('plugins/vectormap/jquery-jvectormap-us-aea-en.js')); ?>"></script>
<script src="<?php echo e(url('plugins/vectormap/jquery-jvectormap-uk-mill-en.js')); ?>"></script>
<script src="<?php echo e(url('plugins/vectormap/jquery-jvectormap-au-mill.js')); ?>"></script>
<script src="<?php echo e(url('js/index.js')); ?>"></script>
<script src="<?php echo e(url('js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(url('js/toastr.min.js')); ?>"></script>
<script src="<?php echo e(url('js/ladda.js')); ?>"></script>
<script src="<?php echo e(url('js/spin.js')); ?>"></script>
<script src="<?php echo e(url('js/datatables.js')); ?>"></script>
<script src="<?php echo e(url('plugins/apexcharts-bundle/js/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(url('js/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(url('plugins/datetimepicker/js/picker.js')); ?>">
</script>
<script src="<?php echo e(url('plugins/datetimepicker/js/picker.time.js')); ?>"></script>
<script src="<?php echo e(url('plugins/datetimepicker/js/picker.date.js')); ?>"></script>
<script src="<?php echo e(url('plugins/bootstrap-material-datetimepicker/js/moment.min.js')); ?>"></script>
<script src="<?php echo e(url('plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.min.js')); ?>">
</script>
<!-- App JS -->
<script src="<?php echo e(url('js/app.js')); ?>"></script>

<script src="<?php echo e(url('js/timesheet.js')); ?>"></script>
<script>
new PerfectScrollbar('.dashboard-social-list');
new PerfectScrollbar('.dashboard-top-countries');
</script>

<script>
$('.datepicker').pickadate({
        selectMonths: true,
        selectYears: true
    }),
    $('.timepicker').pickatime()
</script>
<script>
$(function() {
    $('#date-time').bootstrapMaterialDatePicker({
        format: 'YYYY-MM-DD HH:mm'
    });
    $('#date').bootstrapMaterialDatePicker({
        time: false
    });
    $('#time').bootstrapMaterialDatePicker({
        date: false,
        format: 'HH:mm'
    });
});
</script>
<?php echo $__env->make('components.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\job\resources\views/company/employee.blade.php ENDPATH**/ ?>