<script src="<?php echo e(url('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(url('js/popper.min.js')); ?>"></script>
<script src="<?php echo e(url('js/bootstrap.min.js')); ?>"></script>
<!--plugins-->
<script src="<?php echo e(url('plugins/simplebar/js/simplebar.min.js')); ?>"></script>
<script src="<?php echo e(url('plugins/metismenu/js/metisMenu.min.js')); ?>"></script>
<script src="<?php echo e(url('plugins/perfect-scrollbar/js/perfect-scrollbar.js')); ?>"></script>
<!-- Vector map JavaScript -->
<script src="<?php echo e(url('plugins/vectormap/jquery-jvectormap-2.0.2.min.js')); ?>"></script>
<script src="<?php echo e(url('plugins/vectormap/jquery-jvectormap-world-mill-en.js')); ?>"></script>
<script src="<?php echo e(url('plugins/vectormap/jquery-jvectormap-in-mill.js')); ?>"></script>
<script src="<?php echo e(url('plugins/vectormap/jquery-jvectormap-us-aea-en.js')); ?>"></script>
<script src="<?php echo e(url('plugins/vectormap/jquery-jvectormap-uk-mill-en.js')); ?>"></script>
<script src="<?php echo e(url('plugins/vectormap/jquery-jvectormap-au-mill.js')); ?>"></script>
<script src="<?php echo e(url('js/index.js')); ?>"></script>
<script src="<?php echo e(url('js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(url('js/toastr.min.js')); ?>"></script>
<script src="<?php echo e(url('js/ladda.js')); ?>"></script>
<script src="<?php echo e(url('js/spin.js')); ?>"></script>
<script src="<?php echo e(url('js/datatables.js')); ?>"></script>
<script src="<?php echo e(url('plugins/apexcharts-bundle/js/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(url('js/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(url('plugins/datetimepicker/js/picker.js')); ?>">
</script>
<script src="<?php echo e(url('plugins/datetimepicker/js/picker.time.js')); ?>"></script>
<script src="<?php echo e(url('plugins/datetimepicker/js/picker.date.js')); ?>"></script>
<script src="<?php echo e(url('plugins/bootstrap-material-datetimepicker/js/moment.min.js')); ?>"></script>
<script src="<?php echo e(url('plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.min.js')); ?>">
</script>
<!-- App JS -->
<script src="<?php echo e(url('js/app.js')); ?>"></script>

<script src="<?php echo e(url('js/timesheet.js')); ?>"></script>
<script>
new PerfectScrollbar('.dashboard-social-list');
new PerfectScrollbar('.dashboard-top-countries');
</script><?php /**PATH C:\xampp\htdocs\job\resources\views/components/footer.blade.php ENDPATH**/ ?>