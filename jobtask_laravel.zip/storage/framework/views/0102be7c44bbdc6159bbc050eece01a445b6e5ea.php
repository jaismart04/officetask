<!DOCTYPE html>
<html>

<head>
    <title>Check For Notification toastr</title>
    <script src="http://demo.itsolutionstuff.com/plugin/jquery.js"></script>
    <link rel="stylesheet" href="http://demo.itsolutionstuff.com/plugin/bootstrap-3.min.css">
</head>

<body>


    <?php echo $__env->make('notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default">
                    <div class="panel-heading">Dashboard</div>
                    <div class="panel-body">
                        Check for notification
                    </div>
                </div>
            </div>
        </div>
    </div>


</body>

</html><?php /**PATH C:\xampp\htdocs\job\resources\views/alert/notification_check.blade.php ENDPATH**/ ?>