<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title>MyTask</title>
    <!--favicon-->
    <link rel="icon" href="images/favicon-32x32.png" type="image/png" />
    <!-- Vector CSS -->
    <link href="<?php echo e(url('plugins/vectormap/jquery-jvectormap-2.0.2.css')); ?>" rel="stylesheet" />
    <!--plugins-->
    <link href="<?php echo e(url('plugins/simplebar/css/simplebar.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(url('plugins/perfect-scrollbar/css/perfect-scrollbar.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(url('plugins/metismenu/css/metisMenu.min.css')); ?>" rel="stylesheet" />
    <!-- loader-->
    <link href="<?php echo e(url('css/pace.min.css')); ?>" rel="stylesheet" />
    <script src="<?php echo e(url('js/pace.min.js')); ?>"></script>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(url('css/bootstrap.min.css')); ?>" />
    <!-- Icons CSS -->
    <link rel="stylesheet" href="<?php echo e(url('css/icons.css')); ?>" />
    <link href="<?php echo e(url('plugins/datetimepicker/css/classic.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(url('css/ladda.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(url('css/toastr.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(url('css/datatables.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(url('plugins/datetimepicker/css/classic.time.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(url('plugins/datetimepicker/css/classic.date.css')); ?>" rel="stylesheet" />
    <!-- App CSS -->
    <link rel="stylesheet" href="<?php echo e(url('css/app.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(url('css/buttons.dataTables.min.css')); ?>" />

    <link rel="stylesheet" href="<?php echo e(url('css/dark-sidebar.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(url('css/dark-theme.css')); ?>" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/3.2.1/css/font-awesome.min.css" rel="stylesheet" />
</head>


<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<header class="top-header">
    <nav class="navbar navbar-expand">
        <div class="left-topbar d-flex align-items-center">
            <a href="javascript:;" class="toggle-btn"> <i class="bx bx-menu"></i>
            </a>
        </div>
        <div class="flex-grow-1 search-bar">
            <div class="input-group">
                <div class="input-group-prepend search-arrow-back">
                    <button class="btn btn-search-back" type="button"><i class="bx bx-arrow-back"></i>
                    </button>
                </div>
                <input type="text" class="form-control" placeholder="search" />
                <div class="input-group-append">
                    <button class="btn btn-search" type="button"><i class="lni lni-search-alt"></i>
                    </button>
                </div>
            </div>

        </div>
        <div class="right-topbar ml-auto">
            <ul class="navbar-nav">
                <li class="nav-item search-btn-mobile">
                    <a class="nav-link position-relative" href="javascript:;"> <i
                            class="bx bx-search vertical-align-middle"></i>
                    </a>
                </li>
                <li class="nav-item dropdown dropdown-lg">
                    <a class="nav-link dropdown-toggle dropdown-toggle-nocaret position-relative" href="javascript:;"
                        data-toggle="dropdown"> <span class="msg-count">0</span>
                        <i class="bx bx-comment-detail vertical-align-middle"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right">
                        <a href="javascript:;">
                            <div class="msg-header">
                                <h6 class="msg-header-title">0 New</h6>
                                <p class="msg-header-subtitle">Application Messages</p>
                            </div>
                        </a>

                        <a href="javascript:;">
                            <div class="text-center msg-footer">View All Messages</div>
                        </a>
                    </div>
                </li>
                <li class="nav-item dropdown dropdown-lg">
                    <a class="nav-link dropdown-toggle dropdown-toggle-nocaret position-relative" href="javascript:;"
                        data-toggle="dropdown"> <i class="bx bx-bell vertical-align-middle"></i>
                        <span class="msg-count">0</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right">
                        <a href="javascript:;">
                            <div class="msg-header">
                                <h6 class="msg-header-title">0 New</h6>
                                <p class="msg-header-subtitle">Application Notifications</p>
                            </div>
                        </a>

                        <a href="javascript:;">
                            <div class="text-center msg-footer">View All Notifications</div>
                        </a>
                    </div>
                </li>
                <li class="nav-item dropdown dropdown-user-profile">
                    <a class="nav-link dropdown-toggle dropdown-toggle-nocaret" href="javascript:;"
                        data-toggle="dropdown">
                        <div class="media user-box align-items-center">
                            <div class="media-body user-info">
                                <p class="user-name mb-0">jaiseelan</p>
                                <p class="designattion mb-0" style="color: #67ef12;">Online</p>
                            </div>
                            <img src="<?php echo e(url('images/pf.PNG')); ?>" class="user-img" alt="user avatar">
                        </div>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right">
                        <div class="dropdown-divider mb-0"></div> <a class="dropdown-item" href=""><i
                                class="bx bx-power-off"></i><span>Logout</span></a>
                    </div>
                </li>

            </ul>
        </div>
    </nav>
</header>
<div class="wrapper">
    <!--sidebar-wrapper-->
    <div class="sidebar-wrapper" data-simplebar="true">
        <div class="sidebar-header">
            <div>
                <h4 class="logo-text">MyTask</h4>
            </div>
            <a href="javascript:;" class="toggle-btn ml-auto"> <i class="bx bx-menu"></i>
            </a>
        </div>
        <!--navigation-->
        <ul class="metismenu" id="menu">
            <li>
                <a href="">
                    <div class="parent-icon icon-color-2"><i class="bx bx-home-alt"></i>
                    </div>
                    <div class="menu-title">Dashboard</div>
                </a>
            </li>

            <li>
                <a class="has-arrow" href="javascript:;">
                    <div class="parent-icon icon-color-10"><i class="bx bx-spa"></i>
                    </div>
                    <div class="menu-title">Company</div>
                </a>
                <ul class="mm-collapse">
                    <li> <a href="<?php echo e(url('addcompany')); ?>"><i class="bx bx-right-arrow-alt"></i>Add Company</a>
                    </li>
                    <li> <a href="<?php echo e(url('companylist')); ?>"><i class="bx bx-right-arrow-alt"></i>Company
                            List</a>
                    </li>
                </ul>
            </li>


            <li class="">
                <a class="has-arrow" href="javascript:;" aria-expanded="false">
                    <div class="parent-icon icon-color-1"> <i class="bx bx-comment-edit"></i>
                    </div>
                    <div class="menu-title">Employee</div>
                </a>
                <ul class="mm-collapse" style="height: 2px;">
                    <li> <a href="form-elements.html"><i class="bx bx-right-arrow-alt"></i>Add Employee</a>
                    </li>
                    <li> <a href="form-input-group.html"><i class="bx bx-right-arrow-alt"></i>Employee List</a>
                    </li>

                </ul>
            </li>



        </ul>
        <!--end navigation-->
    </div>
    <!--end sidebar-wrapper-->

    <!--start overlay-->
    <div class="overlay toggle-btn-mobile"></div>
    <!--end overlay-->
    <!--Start Back To Top Button-->
    <a href="javaScript:;" class="back-to-top"><i class='bx bxs-up-arrow-alt'></i></a>
    <!--End Back To Top Button-->
    <!--footer -->
    <div class="footer">
        <p class="mb-0"> @2022  | Developed : <a href="" target="_blank"></a>
        </p>
    </div>
    <!-- end footer -->
</div>
<div class="page-wrapper">
    <!--page-content-wrapper-->
    <div class="page-content-wrapper">
        <div class="page-content">
            <!--breadcrumb-->

            <!--end breadcrumb-->
            <div class="card">
                <div class="card-body">

                    <button type="button" class="btn btn-primary float-right" data-toggle="modal"
                        data-target=".bd-example-modal-lg">Add Company</button>


                    <div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog"
                        aria-labelledby="myLargeModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="row">
                                    <div class="col-xl-12 mx-auto">
                                        <div class="">
                                            <div class="">

                                                <form action="<?php echo e(url('company-save')); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="border p-4 rounded">
                                                        <div class="card-title d-flex align-items-center">
                                                            <div><i class="bx bxs-user me-1 font-22 text-info"></i>
                                                            </div>
                                                            <h5 class="mb-0 text-info">Company Registration</h5>
                                                        </div>
                                                        <hr>
                                                        <div class="row mb-3">
                                                            <label for="inputEnterYourName"
                                                                class="col-sm-3 col-form-label">Enter Company
                                                                Name</label>
                                                            <div class="col-sm-9">
                                                                <input type="text" class="form-control"
                                                                    name="company_name" id="inputEntercompanyName"
                                                                    placeholder="Enter Company Name"
                                                                    value="<?php echo e(old('company_name')); ?>">
                                                            </div>
                                                        </div>

                                                        <div class="row mb-3">
                                                            <label for="inputEmailAddress2"
                                                                class="col-sm-3 col-form-label">Email
                                                                Address</label>
                                                            <div class="col-sm-9">
                                                                <input type="email" class="form-control" name="email"
                                                                    id="inputEmailAddress2" placeholder="Email Address"
                                                                    value="<?php echo e(old('email')); ?>">
                                                            </div>
                                                        </div>

                                                        <div class=" row mb-3">
                                                            <label for="inputEmailAddress2"
                                                                class="col-sm-3 col-form-label">Company Logo
                                                                Address</label>
                                                            <div class="col-sm-9">
                                                                <input class="form-control" name="logo" type="file"
                                                                    id="formFile">
                                                            </div>
                                                        </div>

                                                        <div class="row">
                                                            <label class="col-sm-3 col-form-label"></label>
                                                            <div class="col-sm-9">
                                                                <button type="submit"
                                                                    class="btn btn-info px-5 float-right">Save</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="table-responsive mt-5">
                        <div id="example_wrapper" class="dataTables_wrapper dt-bootstrap4">
                            <div class="row">
                                <div class="col-sm-12 col-md-6">
                                    <div class="dataTables_length" id="example_length"><label>Show <select
                                                name="example_length" aria-controls="example"
                                                class="custom-select custom-select-sm form-control form-control-sm">
                                                <option value="10">10</option>
                                                <option value="25">25</option>
                                                <option value="50">50</option>
                                                <option value="100">100</option>
                                            </select> entries</label></div>
                                </div>
                                <div class="col-sm-12 col-md-6">
                                    <div id="example_filter" class="dataTables_filter"><label>Search:<input
                                                type="search" class="form-control form-control-sm" placeholder=""
                                                aria-controls="example"></label></div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12">
                                    <table id="example" class="table table-striped table-bordered dataTable"
                                        style="width: 100%;" role="grid" aria-describedby="example_info">
                                        <thead>
                                            <tr role="row">
                                                <th class="sorting_asc" tabindex="0" aria-controls="example" rowspan="1"
                                                    colspan="1" aria-sort="ascending"
                                                    aria-label="Name: activate to sort column descending"
                                                    style="width: 158px;">Company Name</th>
                                                <th class="sorting" tabindex="0" aria-controls="example" rowspan="1"
                                                    colspan="1" aria-label="Position: activate to sort column ascending"
                                                    style="width: 245px;">Logo</th>
                                                <th class="sorting" tabindex="0" aria-controls="example" rowspan="1"
                                                    colspan="1" aria-label="Office: activate to sort column ascending"
                                                    style="width: 114px;">Email</th>

                                            </tr>
                                        </thead>
                                        <tbody>

                                            <tr role="row" class="odd">
                                                <td class="sorting_1">Airi Satou</td>
                                                <td>Accountant</td>
                                                <td>Tokyo</td>

                                            </tr>
                                        </tbody>

                                    </table>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12 col-md-5">
                                    <div class="dataTables_info" id="example_info" role="status" aria-live="polite">
                                        Showing 1 to 10 of 57 entries</div>
                                </div>
                                <div class="col-sm-12 col-md-7">
                                    <div class="dataTables_paginate paging_simple_numbers" id="example_paginate">
                                        <ul class="pagination">
                                            <li class="paginate_button page-item previous disabled"
                                                id="example_previous"><a href="#" aria-controls="example"
                                                    data-dt-idx="0" tabindex="0" class="page-link">Prev</a></li>
                                            <li class="paginate_button page-item active"><a href="#"
                                                    aria-controls="example" data-dt-idx="1" tabindex="0"
                                                    class="page-link">1</a></li>
                                            <li class="paginate_button page-item "><a href="#" aria-controls="example"
                                                    data-dt-idx="2" tabindex="0" class="page-link">2</a></li>
                                            <li class="paginate_button page-item "><a href="#" aria-controls="example"
                                                    data-dt-idx="3" tabindex="0" class="page-link">3</a></li>
                                            <li class="paginate_button page-item "><a href="#" aria-controls="example"
                                                    data-dt-idx="4" tabindex="0" class="page-link">4</a></li>
                                            <li class="paginate_button page-item "><a href="#" aria-controls="example"
                                                    data-dt-idx="5" tabindex="0" class="page-link">5</a></li>
                                            <li class="paginate_button page-item "><a href="#" aria-controls="example"
                                                    data-dt-idx="6" tabindex="0" class="page-link">6</a></li>
                                            <li class="paginate_button page-item next" id="example_next"><a href="#"
                                                    aria-controls="example" data-dt-idx="7" tabindex="0"
                                                    class="page-link">Next</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <!--end page-content-wrapper-->
</div>


<script src="<?php echo e(url('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(url('js/popper.min.js')); ?>"></script>
<script src="<?php echo e(url('js/bootstrap.min.js')); ?>"></script>
<!--plugins-->
<script src="<?php echo e(url('plugins/simplebar/js/simplebar.min.js')); ?>"></script>
<script src="<?php echo e(url('plugins/metismenu/js/metisMenu.min.js')); ?>"></script>
<script src="<?php echo e(url('plugins/perfect-scrollbar/js/perfect-scrollbar.js')); ?>"></script>
<!-- Vector map JavaScript -->
<script src="<?php echo e(url('plugins/vectormap/jquery-jvectormap-2.0.2.min.js')); ?>"></script>
<script src="<?php echo e(url('plugins/vectormap/jquery-jvectormap-world-mill-en.js')); ?>"></script>
<script src="<?php echo e(url('plugins/vectormap/jquery-jvectormap-in-mill.js')); ?>"></script>
<script src="<?php echo e(url('plugins/vectormap/jquery-jvectormap-us-aea-en.js')); ?>"></script>
<script src="<?php echo e(url('plugins/vectormap/jquery-jvectormap-uk-mill-en.js')); ?>"></script>
<script src="<?php echo e(url('plugins/vectormap/jquery-jvectormap-au-mill.js')); ?>"></script>
<script src="<?php echo e(url('js/index.js')); ?>"></script>
<script src="<?php echo e(url('js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(url('js/toastr.min.js')); ?>"></script>
<script src="<?php echo e(url('js/ladda.js')); ?>"></script>
<script src="<?php echo e(url('js/spin.js')); ?>"></script>
<script src="<?php echo e(url('js/datatables.js')); ?>"></script>
<script src="<?php echo e(url('plugins/apexcharts-bundle/js/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(url('js/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(url('plugins/datetimepicker/js/picker.js')); ?>">
</script>
<script src="<?php echo e(url('plugins/datetimepicker/js/picker.time.js')); ?>"></script>
<script src="<?php echo e(url('plugins/datetimepicker/js/picker.date.js')); ?>"></script>
<script src="<?php echo e(url('plugins/bootstrap-material-datetimepicker/js/moment.min.js')); ?>"></script>
<script src="<?php echo e(url('plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.min.js')); ?>">
</script>
<!-- App JS -->
<script src="<?php echo e(url('js/app.js')); ?>"></script>

<script src="<?php echo e(url('js/timesheet.js')); ?>"></script>
<script>
new PerfectScrollbar('.dashboard-social-list');
new PerfectScrollbar('.dashboard-top-countries');
</script>

<script>
$('.datepicker').pickadate({
        selectMonths: true,
        selectYears: true
    }),
    $('.timepicker').pickatime()
</script>
<script>
$(function() {
    $('#date-time').bootstrapMaterialDatePicker({
        format: 'YYYY-MM-DD HH:mm'
    });
    $('#date').bootstrapMaterialDatePicker({
        time: false
    });
    $('#time').bootstrapMaterialDatePicker({
        date: false,
        format: 'HH:mm'
    });
});
</script><?php /**PATH C:\xampp\htdocs\job\resources\views/company/company_list.blade.php ENDPATH**/ ?>