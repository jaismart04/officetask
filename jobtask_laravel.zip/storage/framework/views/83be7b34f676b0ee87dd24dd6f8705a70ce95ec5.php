
<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <!--page-content-wrapper-->
    <div class="page-content-wrapper">
        <div class="page-content">

            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <!--breadcrumb-->

            <!--end breadcrumb-->
            <div class="row">
                <div class="col-xl-10 mx-auto">
                    <div class="card border-top border-0 border-4 border-info">
                        <div class="card-body">
                            <div class="border p-4 rounded">
                                <form action="<?php echo e(url('company-update')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>

                                    <input type="hidden" name="id" value="<?php echo e($company->id); ?>">
                                    <div class="border p-4 rounded">
                                        <div class="card-title d-flex align-items-center">
                                            <div><i class="bx bxs-user me-1 font-22 text-info"></i>
                                            </div>
                                            <h5 class="mb-0 text-info">Update Company</h5>
                                        </div>
                                        <hr>
                                        <div class="row mb-3">
                                            <label for="inputEnterYourName" class="col-sm-3 col-form-label">Enter
                                                Company
                                                Name</label>
                                            <div class="col-sm-9">
                                                <input type="text" class="form-control" name="company_name"
                                                    id="inputEntercompanyName" placeholder="Enter Company Name"
                                                    value="<?php echo e($company->company_name); ?>">
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <label for="inputEmailAddress2" class="col-sm-3 col-form-label">Email
                                                Address</label>
                                            <div class="col-sm-9">
                                                <input type="email" class="form-control" name="email"
                                                    id="inputEmailAddress2" placeholder="Email Address"
                                                    value="<?php echo e($company->email); ?>">
                                            </div>
                                        </div>

                                        <div class=" row mb-3">
                                            <label for="inputEmailAddress2" class="col-sm-3 col-form-label">Company Logo
                                                Address</label>
                                            <div class="col-sm-9">
                                                <input class="form-control" name="logo" type="file" id="formFile">
                                            </div>
                                        </div>

                                        <div class="row">
                                            <label class="col-sm-3 col-form-label"></label>
                                            <div class="col-sm-9">
                                                <button type="submit"
                                                    class="btn btn-info px-5 float-right">Save</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>




                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <!--end page-content-wrapper-->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\job\resources\views/company/company_edit.blade.php ENDPATH**/ ?>