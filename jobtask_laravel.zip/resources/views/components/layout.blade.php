@include('components.header')
@yield('content')
@include('components.footer')